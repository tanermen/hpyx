import React, { Component } from 'react'

class HomeHotProduct extends Component{
    constructor(props){
        super(props)
    }
    render(){
        return(
                <div className='home_hot_product'>
                    
                </div>
            )
    }
}
export default HomeHotProduct
