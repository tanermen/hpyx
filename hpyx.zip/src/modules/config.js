import {Component} from 'react'
const config = {
    imagehost:'http://mall.fjncjy.com/'
}

Component.prototype.config = config

export default config
