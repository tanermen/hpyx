
import CommonsActionCreator from '../../store/commons/actionCreator'
import CartActionCreator from '../../store/cart/actionCreator'


export default {
    commons: CommonsActionCreator,
    cart: CartActionCreator
}