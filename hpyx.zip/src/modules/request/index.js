import  React from 'react'
import Get from './get'
import Post from './post.js'

React.Component.prototype.Get = Get

React.Component.prototype.Post = Post

export{Get,Post}
