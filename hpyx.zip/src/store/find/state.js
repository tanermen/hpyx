export default{
    search_history:['香蕉','黄皮']
}
